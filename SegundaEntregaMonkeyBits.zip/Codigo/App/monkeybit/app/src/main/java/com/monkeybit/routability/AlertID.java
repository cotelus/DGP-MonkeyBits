package com.monkeybit.routability;

public enum AlertID {
    LOGOUT,
    DELETEACCOUNT,
}
