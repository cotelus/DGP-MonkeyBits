package com.monkeybit.routability;

public interface AlertDialogResponseInterface {
    public void PositiveResponse(AlertID alertID);
    public void NegativeResponse(AlertID alertID);
}
